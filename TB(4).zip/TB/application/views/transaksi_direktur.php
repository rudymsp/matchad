<!DOCTYPE html>
<?php
  //proteksi halaman
  $this->simple_login->cek_login();
?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href=<?php echo base_url()."css/bootstrap.min.css";?>>
  	<link rel="stylesheet" href=<?php echo base_url()."css/extra.css";?>>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  	<script src=<?php echo base_url()."js/bootstrap.min.js";?>></script>
	<title>Halaman Transaksi</title>
	<!-- Icon Peringatan & Reward -->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img src="http://placehold.it/150x75&text=Logo" ></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo base_url('Crud/home') ?>">Main Dashboard</a></li>
                <li role="separator" class="divider"></li>
                <?php 
                      $hakses= $this->session->userdata('hakakses');
                      if ($hakses =='Admin') { echo '<li><a href="data_user">Account User</a></li>';
                                               echo '<li role="separator" class="divider"></li>';
                      }
                      if ($hakses =='Admin' or $hakses =='Head') { echo '<li><a href="tambah">Input Project New</a></li>';}
                      if ($hakses =='Admin' or $hakses =='BOD') { echo '<li><a href="update">ACC Project (Goal) Dept</a></li>';}
                ?>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo base_url('Crud/chgpass') ?>">Change Password</a></li>
                <li><a href="<?php echo base_url('Crud/logout') ?>">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <!--content-->
	<div class="row clearfix">
		<div class="col-lg-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h1 style="text-align:center;">Form Acc Project (Goal)</h1>
				</div>
				<div class="panel-body">
					<form action="<?php echo base_url(). 'Crud/cari_data'; ?>" method="post">
						<div class="form-group">
					    	<label class="control-label col-sm-1" for="namaproject">Departemen:</label>
					    	<div class="col-sm-4">
					    		<select name="dept" id="dept" class="form-control input-md select2">
									<option value="IT">IT</option>
									<option value="HC">HC</option>
									<option value="PAT">PAT</option>
									<option value="GA">GA</option>
									<option value="MARKETING">MARKETING</option></option>
									<option value="FINANCE">FINANCE</option>
									<option value="LOGISTIC">LOGISTIC</option>
									<option value="PRODUCTION">PRODUCTION</option>
									<option value="SITAC">SITAC</option>
									<option value="ACCOUNTING">ACCOUNTING</option>
									<option value="INTERNAL AUDIT">INTERNAL AUDIT</option>
								</select>
					    	</div>
					    	<label class="control-label col-sm-1" for="namaproject">Kota:</label>
					    	<div class="col-sm-4">
					    		<select name="cabang" id="cabang" class="form-control input-md select2">
									<option value="SURABAYA">SURABAYA</option>
									<option value="JAKARTA">JAKARTA</option>
								</select>
					    	</div>
					    	<div class="col-sm-2">
					    		<button type="submit" class="btn btn-primary">Search</button>
					    		<a href="update" type="button" class="btn btn-primary">Refresh</a>
					    	</div>
					  	</div>
					</form><br><br>
					<table class="table table-striped table-condensed table-bordered">
		    			<thead>
			    			<tr>
			    				<th>No</th>
			    				<th>Nama Project</th>
			    				<th>Departemen</th>
			    				<th>PIC</th>
			    				<th>Start Project</th>
			    				<th>End Project(Deadline)</th>
			    				<th>Progress</th>
			    				<th>Peringatan</th>
			    				<th>Status</th>
			    				<th>Reward</th>
			    				<th>Action</th>
			    			</tr>
		    			</thead>
		    			<tbody>
		    			    <?php 
		                         foreach($dataproject as $d){ 
		                    ?>
		    				<tr>
		    					<td><?php echo $d->id ?></td>
    					        <td><?php echo $d->project ?></td>
    					        <td><?php echo $d->dept ?></td>
    					        <td><?php echo $d->pic ?></td>
    					        <td><?php echo $d->project_start ?></td>
    					        <td><?php echo $d->project_end ?></td>
    					        <td><?php echo $d->progress ?></td>
    					        <form action="<?php echo base_url(). 'Crud/update_aksi'; ?>" method="post">
    					        <td>
		    					    <i class="material-icons" style="font-size:25px;color:red">warning</i>
		    					    <div class="col-sm-10">
					    		         <input type="text" class="form-control" name="peringatan" id="peringatan" placeholder="peringatan" value=<?php echo $d->peringatan ?>>
					    	        </div>
		    					</div>
		    					</td>
		    					<td>
		    					    <span class="glyphicon glyphicon-gift" aria-hidden="true"></span>
		    					    <div class="col-sm-10">
		    					        <select name="status" id="status" class="form-control input-md select2">
		    					                <?php if ($d->status == "INTIME") { echo '
		    					                <option value="">Pilihan</option>
									        	<option selected="selected" value="INTIME">INTIME</option>
										        <option value="ONTIME">ONTIME</option>
										        <option value="OVERTIME">OVERTIME</option>
										        <option value="PENDING">PENDING</option>' ;} else
										        if ($d->status == "ONTIME") { echo '
										        <option value="">Pilihan</option>
									        	<option value="INTIME">INTIME</option>
										        <option selected="selected" value="ONTIME">ONTIME</option>
										        <option value="OVERTIME">OVERTIME</option>
										        <option value="PENDING">PENDING</option>' ;} else
										        if ($d->status == "OVERTIME") { echo '
										        <option value="">Pilihan</option>
									        	<option value="INTIME">INTIME</option>
										        <option value="ONTIME">ONTIME</option>
										        <option selected="selected" value="OVERTIME">OVERTIME</option>
										        <option value="PENDING">PENDING</option>' ;} else
										        if ($d->status == "PENDING") { echo '
										        <option value="">Pilihan</option>
									        	<option value="INTIME">INTIME</option>
										        <option value="ONTIME">ONTIME</option>
										        <option value="OVERTIME">OVERTIME</option>
										        <option selected="selected" value="PENDING">PENDING</option>' ;} else
										        {echo '
										        <option value="">Pilihan</option>
										        <option value="INTIME">INTIME</option>
										        <option value="ONTIME">ONTIME</option>
										        <option value="OVERTIME">OVERTIME</option>
										        <option value="PENDING">PENDING</option>' ;    
										        }
										        ?>
									    </select>
									</div>
                                </td>
                                <td>
		    					    <i class="fa fa-gift" style="font-size:25px;color:blue"></i> 
		    					    <div class="col-sm-10">
                                         <input type="text" class="form-control" name="reward" id="peringatan" placeholder="reward" value=<?php echo $d->reward ?>>
					    	        </div>
		    					</div>
		    					</td>
                                <td>
									<button type="submit" style="font-size:8px;color:green">ACC<i class="material-icons" style="font-size:9px;color:green">offline_pin</i></button>
									
								</td>
								<td><input type="hidden" name="id" value=<?php echo $d->id ?>></td>
                                </form>
		    				</tr>
		    				<?php } ?>
		    			</tbody>
		    		</table>
				</div>
			</div>
		</div>
	</div>
    <!--content-->
    <!--footer-->
    <div>
        <center>
        <tr<td><b>Intime   =</b> Selesai Sebelum Deadline |</td></tr>
        <tr><td><b>Ontime   =</b> Selesai Sesesuai Deadline |</td></tr>
        <tr><td><b>Overtime =</b> Selesai Melebihi Deadline |</td></tr>
        <tr><td><b>Pending  =</b> Sesuai Kebijakan BOD </td></tr>
        </center>
    </div>
    <div class="row clearfix">
			<div class="col-lg-12">
				<div class="panel panel-primary">
				<div class="panel-body">
					<p style="text-align:center; margin-bottom: 0px;">Hak Cipta @2017 Designed by Match Ad</p>
				</div>
			</div>
		</div>
	</div>
	<!--footer-->

</body>
</html>
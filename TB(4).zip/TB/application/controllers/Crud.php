<?php 

    defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller{
	public function login_user()
	{
		//fungsi login
		$valid = $this->form_validation;
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$valid->set_rules('username','Username','required');
		$valid->set_rules('password','Password','required');
		if($valid->run())
		{
			$this->simple_login->login($username,$password);
		}
	}
	
	//logout disini
	public function logout()
	{
		$this->simple_login->logout();
	}
 
	function __construct(){
		parent::__construct();		
		$this->load->model('M_data');
                $this->load->helper('url');
	}
 
	function index(){
	    $table='dataproject';
		$data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('index',$data);
	}
	
	function login(){
	    $this->load->view('login');
	}
	
	function tambah(){
	    $table='dataproject';
	    $id= $this->session->userdata('id');
	    $dep=$this->M_data->getDepartDt($id);
	    $depts=explode(",", $dep->dept);
	    $data['dataproject'] = $this->M_data->tampil_data_dept($depts,$table)->result();
		$this->load->view('transaksi',$data);
	}
	
	function tambah_aksi(){
		$project = $this->input->post('namaproject');
		$dept = $this->input->post('dept');
		$start = $this->input->post('start');
        $end = $this->input->post('end');
        $pic = $this->input->post('pic');
        $cab = $this->input->post('cabang');
        $progress = $this->input->post('progress');
		$data = array(
			'project' => $project,
			'dept' => $dept,
			'project_start' => $start,
			'project_end' => $end,
			'pic' => $pic,
			'progress' => $progress,
			'cabang' => $cab
			);
	    $table = 'dataproject';
		$this->M_data->input_data($data,$table);
		redirect('Crud/tambah');
	}
	
	function update_aksi_project(){
		$id = $this->input->post('id');
	    $where =  array('id' => $id);
	    $project1 = $this->input->post('namaproject1');
		$dept1 = $this->input->post('dept1');
		$pic1 = $this->input->post('pic1');
        $cab1 = $this->input->post('cab1');
        $progress1 = $this->input->post('progress1');
        $data = array(
			'id' => $id,
			'project' => $project1,
			'dept' => $dept1,
			'pic' => $pic1,
			'cabang' => $cab1,
			'progress' => $progress1
			);
		$table = 'dataproject';
		$this->M_data->update_data($where,$data,$table);
		redirect('Crud/tambah');
	}
	
	function update(){
	    $table='dataproject';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('transaksi_direktur',$data);
	}
	
	function update_aksi(){
	    $id = $this->input->post('id');
	    $where =  array('id' => $id);
	    $peringatan = $this->input->post('peringatan');
	    $status = $this->input->post('status');
	    $reward = $this->input->post('reward');
	    $data = array(
			'id' => $id,
			'status' => $status,
			'peringatan' => $peringatan,
			'reward' => $reward
			);
		$table = 'dataproject';
		$this->M_data->update_data($where,$data,$table);
		redirect('Crud/update');
	}
	
	function update_project(){
	    $table='dataproject';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('transaksi_update',$data);
	}
	
	function hapus_project(){
	    $table='dataproject';
		$data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('hapus_project',$data);
	}
	
	function hapus_project_aksi(){
	     $id=$this->uri->segment(3);
	     $this->M_data->delPrj($id);
	     redirect ('Crud/hapus_project?sts=deletesukses');
	}
	
	function cari_data(){
	    $table = 'dataproject';
	    $spe1  = 'dept';
	    $spe2  = 'cabang'; 
	    $search1 = $this->input->post('dept');
	    $search2 = $this->input->post('cabang');
	    $data['dataproject'] = $this->M_data->search_data($table,$spe1,$spe2,$search1,$search2);
		$this->load->view('transaksi_direktur',$data);
	}
	
	function home(){
	    $table='dataproject';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('home',$data);
	}
	
	function data_user(){
	    $table='users';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('data_user',$data);
	}
	
	function tambah_user(){
	    $table='users';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('tambah_user',$data);
	}
	
	function tambah_user_aksi(){
		$nama = $this->input->post('nama');
		$namauser = $this->input->post('username');
		$password = $this->input->post('pass');
		$mail = $this->input->post('mail');
		$dept = $this->input->post('dept[]');
		$hakakses = $this->input->post('hakakses');
        $status = $this->input->post('status');
		$data = array(
			'nama' => $nama,
			'username' => $namauser,
			'password' => $password,
			'mail' => $mail,
			'dept' => implode(",",$dept),
			'hakakses' => $hakakses,
			'status' => $status
			);
	    $table = 'users';
		$this->M_data->input_data($data,$table);
		redirect('Crud/tambah_user');
	}
	
	function ubah_user(){
	    $id=$this->uri->segment(3);
	    $data['usr']=$this->M_data->getUsrUpDt($id);
		$data['dep']=$this->M_data->getDepartDt($id);
		//$data['aks']=$this->M_data->getAccDt($id);
	    $table='users';
	    $data['dataproject'] = $this->M_data->tampil_data($table)->result();
		$this->load->view('ubah_user',$data);
	}
	
	function ubah_user_aksi(){
	    $id= $this->input->post('id');
	    $where =  array('id_user' => $id);
	    $nama = $this->input->post('nama');
		$namauser = $this->input->post('username');
		$password = $this->input->post('pass');
		$mail = $this->input->post('mail');
		$dept = $this->input->post('dept[]');
		$hakakses = $this->input->post('hakakses');
        $status = $this->input->post('status');
		$data = array(
			'nama' => $nama,
			'username' => $namauser,
			'password' => $password,
			'mail' => $mail,
			'dept' => implode(",",$dept),
			'hakakses' => $hakakses,
			'status' => $status
			);
	    $table = 'users';
		$this->M_data->update_data($where,$data,$table);
		redirect('Crud/data_user');
	}
	
	function hapus_user(){
	     $id=$this->uri->segment(3);
	     $this->M_data->delUsr($id);
	     redirect ('Crud/data_user?sts=deletesukses');
	}
	
	public function menu_ChgPass()
	{
			$id=$this->session->userdata('id');
			$data['title']='Halaman Admin';
			$data['isi']='menu/admin/admChgPass_View';
			$data['usrdt']=$this->M_data->getUsrDt($id);
			$this->load->view('ganti_pass',$data);
	}
		
	public function chgPass()
	{
			$id=$this->session->userdata('id');
			$this->form_validation->set_rules('passbaru','Password Baru','required');
			
			if($this->form_validation->run() === FALSE)
			{
				$this->menu_ChgPass();
			}
			else
			{
				$pass=$this->input->post('passbaru');
				$result=$this->M_data->upd_Pass($id,$pass);
				if($result == '0')
				{
					$data["msg"]='<div class="col-lg-12"><div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>Data Gagal Diubah</div></div>';
				}
				else
				{
					$data["msg"]='<div class="col-lg-12"><div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span></button>Data Sukses Diubah</div></div>';
				}
				$this->load->vars($data);
				$this->menu_ChgPass();
			}
	}
}
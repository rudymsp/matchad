<?php
	//panggil semua layout
	require_once('head.php');
	require_once('header_index.php');
	require_once('konten.php');
	//require_once('tinymce.php');
	require_once('footer.php');
	//require_once('tinymce.php');
?>
<!DOCTYPE html>
<?php
  //proteksi halaman
  $this->simple_login->cek_login();
?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href=<?php echo base_url()."css/bootstrap.min.css";?>>
  	<link rel="stylesheet" href=<?php echo base_url()."css/extra.css";?>>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  	<script src=<?php echo base_url()."js/bootstrap.min.js"; ?>></script>
	<title>Halaman Transaksi</title>
</head>
<body>
	<!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img src="http://placehold.it/150x75&text=Logo" ></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo base_url('Crud/home') ?>">Main Dashboard</a></li>
                <li role="separator" class="divider"></li>
                <?php 
                      $hakses= $this->session->userdata('hakakses');
                      if ($hakses =='Admin') { echo '<li><a href="data_user">Account User</a></li>';
                                               echo '<li role="separator" class="divider"></li>';
                      }
                      if ($hakses =='Admin' or $hakses =='Head') { echo '<li><a href="tambah">Input Project New</a></li>';}
                      if ($hakses =='Admin' or $hakses =='BOD') { echo '<li><a href="update">ACC Project (Goal) Dept</a></li>';}
                ?>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo base_url('Crud/chgpass') ?>">Change Password</a></li>
                <li><a href="<?php echo base_url('Crud/logout') ?>">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <!--content-->
	<div class="row clearfix">
		<div class="col-lg-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h1 style="text-align:center;">Project New Time Table</h1>
				</div>
				<div class="panel-body">
					<form class="form-horizontal" action="<?php echo base_url(). 'crud/tambah_aksi'; ?>" method="post">
						<div class="form-group">
					    	<label class="control-label col-sm-2" for="namaproject">Nama Project (Goal):</label>
					    	<div class="col-sm-10">
					    		<input type="text" class="form-control" name="namaproject" id="namaproject" placeholder="Nama Project">
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="Departemen">Departemen:</label>
					    	<div class="col-sm-10">
					      		<select name="dept" id="dept" class="form-control input-md select2">
									<option value="IT">IT</option>
									<option value="HC">HC</option>
									<option value="PAT">PAT</option>
									<option value="GA">GA</option>
									<option value="MARKETING">MARKETING</option>
									<option value="FINANCE">FINANCE</option>
									<option value="LOGISTIC">LOGISTIC</option>
									<option value="PRODUCTION">PRODUCTION</option>
									<option value="SITAC">SITAC</option>
									<option value="ACCOUNTING">ACCOUNTING</option>
									<option value="INTERNAL AUDIT">INTERNAL AUDIT</option>
								</select>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="start">Project Start:</label>
					    	<div class="col-sm-10">
					      		<div class="input-group">
					      		<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					      		<input type="date" class="form-control" name="start" id="start" placeholder="yyyy-mm-dd">
					      		</div>
						    </div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="end">Project End:</label>
					    	<div class="col-sm-10">
					      		<div class="input-group">
					      		<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					      		<input type="date" class="form-control" name="end"id="end" placeholder="yyyy-mm-dd">
					      		</div>
						    </div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="pic">PIC:</label>
					    	<div class="col-sm-10">
					    		<input type="text" class="form-control" name="pic" id="pic" placeholder="Nama PIC" >
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="progress">Progress:</label>
					    	<div class="col-sm-10">
					    		<textarea style="resize:vertical;" rows="5" class="form-control" name="progress" id="progress" placeholder="Progress" ></textarea>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="Cabang">Cabang:</label>
					    	<div class="col-sm-10">
					      		<select name="cabang" id="cabang" class="form-control input-md select2">
									<option value="JAKARTA">Jakarta</option>
									<option value="SURABAYA">Surabaya</option>
								</select>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<div class="col-sm-offset-2 col-sm-10">
					      		<button type="submit" class="btn btn-primary">Save</button>
					      		<button type="submit" class="btn btn-default">Cancel</button>
					    	</div>
					  	</div>
					</form>
					<table class="table table-striped table-condensed table-bordered">
		    			<thead>
			    			<tr>
			    				<th>No</th>
			    				<th>Nama Project</th>
			    				<th>Departemen</th>
			    				<th>PIC</th>
			    				<th>Start Project</th>
			    				<th>End Project(Deadline)</th>
			    				<th>Progress</th>
			    				<th>Cabang</th>
			    				<th>Action</th>
			    			</tr>
		    			</thead>
		    			<tbody>
		    			    <?php 
		                         foreach($dataproject as $d){ 
		                    ?>
		    				<tr>
		    				    <form action="<?php echo base_url(). 'Crud/update_aksi_project'; ?>" method="post">
		    					<td><?php echo $d->id ?></td>
    					        <td><input type="text" class="form-control" name="namaproject1" id="namaproject1" placeholder="namaproject1" value="<?php echo $d->project ?>"></td>
    					        <td><input type="text" class="form-control" name="dept1" id="dept1" placeholder="dept1" value="<?php echo $d->dept ?>"></td>
    					        <td><input type="text" class="form-control" name="pic1" id="pic1" placeholder="pic1" value="<?php echo $d->pic ?>"></td>
    					        <td><?php echo $d->project_start ?></td>
    					        <td><?php echo $d->project_end ?></td>
    					        <td><input type="text" class="form-control" name="progress1" id="progress1" placeholder="progess" value="<?php echo $d->progress ?>"></td>
    					        <td><input type="text" class="form-control" name="cab1" id="cab1" placeholder="cabang" value="<?php echo $d->cabang ?>"></td>
                                <td>
									<button type="submit"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>
								</td>
								<td><input type="hidden" name="id" value=<?php echo $d->id ?>></td>
                                </form>
		    				</tr>
		    				<?php } ?>
		    			</tbody>
		    		</table>
				</div>
			</div>
		</div>
	</div>
    <!--content-->
    <!--footer-->
    <div class="row clearfix">
			<div class="col-lg-12">
				<div class="panel panel-primary">
				<div class="panel-body">
					<p style="text-align:center; margin-bottom: 0px;">Hak Cipta @2016 Designed by Match Ad Ver 1.0</p>
				</div>
			</div>
		</div>
	</div>
	<!--footer-->
</body>
</html>
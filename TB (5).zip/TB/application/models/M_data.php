<?php
      class M_data extends CI_Model{
          function tampil_data($table){
		           return $this->db->get($table);
          }
          
          function tampil_data_warning($where,$table){
                   $this->db->select("*");
                   $this->db->where($where);
			       return $this->db->get($table);
          }
          function tampil_data_dept($where,$table){
                   $this->db->select("*");
                   $this->db->where_in('dept',$where);
			       return $this->db->get($table);
          }
          
          function input_data($data,$table){
	               $this->db->insert($table,$data);
	      }
	      
	      function update_data($where,$data,$table){
	               $this->db->where($where);
	               $this->db->update($table,$data);
	      }
	      
	      function search_data($table,$spe1,$spe2,$srch1=NULL,$srch2=NULL){
	               if($srch1 == "NULL") $srch1 = "";
	               if($srch2 == "NULL") $srch2 = "";
			       $sql = "SELECT * FROM ".$table." WHERE ".$spe1."='".$srch1."' and ".$spe2."='".$srch2."'";
			       $query = $this->db->query($sql);
			       return $query->result();
	      }
	      
	      public function getUsrDt($id)
		  {
			$query = $this->db->select('*')->where('id_user',$id)->get('users');
			return $query->result();
		  }
		
	      public function getUsrUpDt($id)
		  {
			$query=$this->db->get_where('users',array('id_user'=>$id));
			return $query->row_array();
		  } 
		  
		  public function getDepartDt($id)
		  {
			$res = $this->db->query('select dept from users where id_user ="'.$id.'" limit 1');
			return $res->row();
		  }
		  
		  public function getAccDt($id=FALSE)
		  {
			if($id === FALSE)
			{
				$query=$this->db->query('select * from akses order by nama_akses desc');
				return $query->result_array();
			}
			else
			{
				$query=$this->db->query('SELECT * FROM akses join users ON akses.id_akses = users.id_akses WHERE users.id_user = "'.$id.'"');
				return $query->row_array();
			}
		  }
		  
		  public function upd_Pass($id,$pass)
		  {
			$data=array ("password"=>$pass);
			
			$this->db->where('users.id_user',$id);
			$this->db->update('users',$data);
			if($this->db->affected_rows())
			{
				return '1';
			}
			else
			{
				return '0';
			}
		  }
		  
		  public function delUsr($id)
		  {
			$this->db->where('id_user',$id);
			$this->db->delete('users');
		  }
		  
		  public function delPrj($id)
		  {
			$this->db->where('id',$id);
			$this->db->delete('dataproject');
		  }
      }
?>
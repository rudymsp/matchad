<footer class="footer">
    <div class="container">
        <p class="text-muted">Copyright PT Wiper Indonesia 2017.</p>
    </div>
</footer>
	<!-- datetime -->
    <script src="<?php echo base_url() ?>assets/js/moment.js"></script>
	<script src="<?php echo base_url() ?>assets/js/bootstrap-datetimepicker.min.js"></script>
    <!-- /datetime -->
	<script src="<?php echo base_url() ?>assets/js/extra.js"></script>
</body>

</html>
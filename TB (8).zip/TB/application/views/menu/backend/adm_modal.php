<!-- Modal -->
    <div class="modal fade" id="<?php echo $id ; ?>" role="dialog">
    	<div class="modal-dialog">
    		<div class="modal-content">
    			<div class="modal-header">
    				<h4 class="modal-title">Upload Image</h4>
    			</div>
    			<div class="modal-body">
    				
    			</div>
    			<div class="modal-footer">
    				<button type="" class="btn btn-default" data-dismiss="modal">
    					Close
    				</button>
    			</div>
    		</div>
    	</div>
    </div>
    <!-- /Modal -->
<!DOCTYPE html>
<?php
  //proteksi halaman
  $this->simple_login->cek_login();
?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href=<?php echo base_url()."css/bootstrap.min.css";?>>
  	<link rel="stylesheet" href=<?php echo base_url()."css/extra.css";?>>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  	<script src=<?php echo base_url()."js/bootstrap.min.js"; ?>></script>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Halaman Transaksi</title>
	<!-- datatable -->
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
	<style>
        .iki.table-striped>tbody>tr:nth-child(odd)>td, 
        .iki.table-striped>tbody>tr:nth-child(odd)>th {
        background-color: #1452b7; color:white;
        }
   </style>
</head>
<body>
	<!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#113672">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img style="height:75px;width:150px" class="img-responsive" src="<?php echo base_url()?>assets/logo/LogoProject.png"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="<?php echo base_url('Crud/home') ?>">Main Dashboard</a></li>
                <li role="separator" class="divider"></li>
                <?php 
                      $hakses= $this->session->userdata('hakakses');
                      if ($hakses =='Admin') { echo '<li><a href="data_user">Account User</a></li>';
                                               echo '<li role="separator" class="divider"></li>';
                      }
                      if ($hakses =='Admin' or $hakses =='Head') { echo '<li><a href="tambah">Input Project New</a></li>';}
                      if ($hakses =='Admin' or $hakses =='BOD') { echo '<li><a href="update">ACC Project (Goal) Dept</a></li>';}
                ?>
                <li role="separator" class="divider"></li>
                <li><a href="<?php echo base_url('Crud/chgpass') ?>">Change Password</a></li>
                <li><a href="<?php echo base_url('Crud/logout') ?>">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <!--content-->
	<div class="row clearfix">
	    <?php if ($this->session->flashdata('message_name')) { ?>
        	<center>
        	<div class="alert alert-info alert-dismissable col-md-4 col-md-offset-4">
                 <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                 <?= $this->session->flashdata('message_name') ?>
          	</div>
          	</center>
        <?php } ?>
        
        <script type="text/javascript">
        $(document).ready(function () {
         
        window.setTimeout(function() {
            $(".alert").fadeTo(1500, 0).slideUp(500, function(){
                $(this).remove(); 
            });
        }, 5000);
         
        });
        </script>
		<div class="col-lg-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h1 style="text-align:center;">Project New Time Table</h1>
				</div>
				<div class="panel-body">
					<form class="form-horizontal" action="<?php echo base_url(). 'crud/tambah_aksi'; ?>" method="post">
						<div class="form-group">
					    	<label class="control-label col-sm-2" for="namaproject">Nama Project (Goal):</label>
					    	<div class="col-sm-10">
					    		<input type="text" class="form-control" name="namaproject" id="namaproject" placeholder="Project Name" required>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="Departemen">Departemen:</label>
					    	<div class="col-sm-10">
					      		<select name="dept" id="dept" class="form-control input-md select2" required>
					      		    <option>- Pilih Department -</option>
									<option value="IT">IT</option>
									<option value="HC">HC</option>
									<option value="PAT">PAT</option>
									<option value="GA">GA</option>
									<option value="MARKETING">MARKETING</option>
									<option value="FINANCE">FINANCE</option>
									<option value="LOGISTIC">LOGISTIC</option>
									<option value="PRODUCTION">PRODUCTION</option>
									<option value="SITAC">SITAC</option>
									<option value="ACCOUNTING">ACCOUNTING</option>
									<option value="INTERNAL AUDIT">INTERNAL AUDIT</option>
									<option value="SECRETARY">SECRETARY</option>
									<option value="WIPER Indonesia">WIPER Indonesia</option>
									<option value="Tritunggal Metalworks">Tritunggal Metalworks</option>
								</select>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="start">Project Start:</label>
					    	<div class="col-sm-10">
					      		<div class="input-group">
					      		<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					      		<input type="date" class="form-control" name="start" id="start" placeholder="yyyy-mm-dd" required>
					      		</div>
						    </div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="end">Project End:</label>
					    	<div class="col-sm-10">
					      		<div class="input-group">
					      		<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					      		<input type="date" class="form-control" name="end"id="end" placeholder="yyyy-mm-dd" required>
					      		</div>
						    </div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="pic">PIC:</label>
					    	<div class="col-sm-10">
					    		<input type="text" class="form-control" name="pic" id="pic" placeholder="PIC Name" required>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="progress">Progress Project:</label>
					    	<div class="col-sm-10">
					    		<textarea style="resize:vertical;" rows="5" class="form-control" name="progress" id="progress" placeholder="Progress"></textarea>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<label class="control-label col-sm-2" for="Cabang">Cabang:</label>
					    	<div class="col-sm-10">
					      		<select name="cabang" id="cabang" class="form-control input-md select2">
					      		    <option>- Pilih Cabang -</option>
									<option value="JAKARTA">Jakarta</option>
									<option value="SURABAYA">Surabaya</option>
								</select>
					    	</div>
					  	</div>
					  	<div class="form-group">
					    	<div class="col-sm-offset-2 col-sm-10">
					      		<button type="submit" class="btn btn-primary">Save</button>
					      		<button type="submit" class="btn btn-default">Cancel</button>
					    	</div>
					  	</div>
					</form>

					
					<table id="dataTables" class="table table-bordered table-hover table-striped iki">
		    			<thead>
			    			<tr style="background-color: #e22639; color:white;">
			    				<!--<th>No</th>-->
			    				<th>Nama Project</th>
			    				<th>Departemen</th>
			    				<th>PIC</th>
			    				<th>Start Project</th>
			    				<th>End Project &nbsp (Deadline)</th>
			    				<th>Progress Project</th>
			    				<th>Cabang</th>
			    				<th>ACC</th>
			    				<th>Action</th> 
			    			</tr>
		    			</thead>
		    			<tbody>
		    			    <?php 
		                         foreach($dataproject as $d){ 
		                    ?>
		    				<tr>
		    				    <form action="<?php echo base_url(). 'Crud/update_aksi_project'; ?>" method="post">
		    				        <input type="hidden" name="id" value=<?php echo $d->id ?>>
		    					<!--<td><?php echo $d->id ?></td>-->
    					        <td><input type="text" class="form-control" name="namaproject1" id="namaproject1" placeholder="Project Name" value="<?php echo $d->project ?>" required></td>
    					        <!--<td><input type="text" class="form-control" name="dept1" id="dept1" placeholder="Department Name" value="<?php echo $d->dept ?>" required></td>-->
    					        <td>
					      		<select name="dept1" id="dept1" class="form-control input-md select2" required>
					      		    <option><?php echo $d->dept ?></option>
									<option value="IT">IT</option>
									<option value="HC">HC</option>
									<option value="PAT">PAT</option>
									<option value="GA">GA</option>
									<option value="MARKETING">MARKETING</option>
									<option value="FINANCE">FINANCE</option>
									<option value="LOGISTIC">LOGISTIC</option>
									<option value="PRODUCTION">PRODUCTION</option>
									<option value="SITAC">SITAC</option>
									<option value="ACCOUNTING">ACCOUNTING</option>
									<option value="INTERNAL AUDIT">INTERNAL AUDIT</option>
									<option value="SECRETARY">SECRETARY</option>
									<option value="WIPER Indonesia">WIPER Indonesia</option>
									<option value="Tritunggal Metalworks">Tritunggal Metalworks</option>
								</select>
					    	    </td>
    					        <td><input type="text" class="form-control" name="pic1" id="pic1" placeholder="PIC Name" value="<?php echo $d->pic ?>" required></td>
    					        <td><?php echo $d->project_start ?></td>
    					        <td><?php echo $d->project_end ?></td>
    					        <td><input type="text" class="form-control" name="progress1" id="progress1" placeholder="Progress" value="<?php echo $d->progress ?>"></td>
    					        <!--<td><input type="text" class="form-control" name="cab1" id="cab1" placeholder="Cabang" value="<?php echo $d->cabang ?>" required></td>-->
                                <td>
                                    <select name="cab1" id="cab1" class="form-control input-md select2">
					      		           <option><?php echo $d->cabang ?></option>
									       <option value="JAKARTA">Jakarta</option>
									       <option value="SURABAYA">Surabaya</option>
								    </select>
                                </td>
                                <?php
                                     if ($d->approved==1) {
                                        echo   '<td><span class="label label-success"><span class="glyphicon glyphicon-ok"></span></span>
                                        </td>';
                                     }else {echo   '<td><span class="label label-success"></span>
                                        </td>';}
                                ?>
                                <td>
									<button type="submit" style="color:black"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>
								</td>
                                </form>
                                
		    				</tr>
		    				<?php } ?>
		    			</tbody>
		    		</table>
				</div>
			</div>
		</div>
	</div>
    <!--content-->
    <!--footer-->
    <div class="row clearfix">
			<div class="col-lg-12">
				<div class="panel panel-primary">
				<div class="panel-body" style="background-color: #3068a5; color:white;">
					<p style="text-align:center; margin-bottom: 0px;">Hak Cipta @2016 Designed by Match Ad</p>
				</div>
			</div>
		</div>
	</div>
	<!--footer-->
	 <script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
  <script>
  $(document).ready(function() {
    $('#dataTables').DataTable({
        "bLengthChange": false,
        "bFilter": false,
        "bInfo" : false,
        "paging": false
    });
  } );
  </script>
</body>
</html>